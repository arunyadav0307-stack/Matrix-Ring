# Matrix Ring manuscript — complete bundle

**Quantum Error-Correcting Codes from Galois Hulls of Cyclic Codes over
Noncommutative Matrix Rings**

Single author: **Arun Kumar Yadav** — School of Basic and Applied Sciences,
K.R. Mangalam University, Sohna Road, Gurugram, Haryana, 122103, India.
Corresponding author: arunyadav0307@gmail.com

Target journal: *Finite Fields and Their Applications* (Elsevier).

Bundle assembled **2026-11-10** from branch `arena/59de606f-matrix-ring`,
commit `fb8e967` (Phase 22).

---

## ⚠️ Read this before using the manuscript

> **EDITORIAL CONFIRMATION REQUIRED**
>
> **PRIVATE DATA ACCESS IS NOT YET ESTABLISHED AS ACCEPTABLE UNDER FFA
> OPTION C.**
>
> This is **not** a submission-ready manuscript, and nothing in this bundle has
> been submitted to any journal. The Data availability section carries the
> **proposed** private-access statement, clearly marked
> `PROPOSED — POLICY VERIFIED — PENDING EDITORIAL CONFIRMATION — NOT COMPLIANT
> AS A FINAL STATEMENT`.

* FFA applies Elsevier research-data **Option C**, which is **required**:
  deposit in a data repository **and** a link at submission, **or** a statement
  explaining **why** sharing isn't possible.
* The researcher has chosen **private access upon reasonable request** and has
  **not** authorised a public deposit, a public GitHub data link, a Zenodo
  deposit, a DOI, a GitHub release, a public tag or a branch merge.
* Whether that arrangement is acceptable is **unsettled** — the official policy
  text nowhere mentions access upon request. A clarification email is drafted
  (`documents/PHASE21_EDITORIAL_CLARIFICATION_EMAIL.md`) and **NOT SENT**.
* **This bundle is not a data deposit and not a data release.** It is a working
  bundle for the author's own use and for private transfer on request. Its
  existence does **not** satisfy Option C.

Two further unresolved items: the **generative-AI declaration** is still an
unconfirmed placeholder, and the canonical manuscript still carries a
**superseded** Data availability section with a withdrawn public GitHub link on
page 37 — that must be replaced before submission on either route.

---

## What is in here

```
MatrixRingManuscript_Phase22/
├── README.md                  this file
├── SHA256_MANIFEST.txt        SHA-256 of every file in this bundle
├── manuscript/                the LaTeX source and the compiled PDF
│   ├── main.tex               the main document (preamble + declarations)
│   ├── references.bib         the bibliography (13 entries)
│   ├── main.pdf               the compiled manuscript, 42 pages
│   └── sections/              12 section and appendix files
├── compile/                   the build toolchain
├── supplementary/             the 86-file research package (programs + data)
└── documents/                 cover letter, checklist, policy and phase reports
```

### `manuscript/` — 15 files

| file | what it is |
|---|---|
| `main.tex` | main LaTeX document. Preamble, title page, abstract, keywords, and the declaration sections (acknowledgements, competing interests, funding, CRediT, **data availability**, generative AI). |
| `references.bib` | bibliography, 13 entries, all cited and all resolved. |
| `sections/01_introduction.tex` … `10_conclusion.tex` | the ten manuscript sections. |
| `sections/appendix_tables.tex`, `appendix_reproducibility.tex` | Appendices A and B (Tables A.1, A.2; environment and reproduction). |

That is **12** section/appendix files in total — 10 sections plus 2 appendices.
(Earlier phase reports said "13"; that was a counting slip, corrected here and
in the repository reports. No manuscript content is affected.)
| `main.pdf` | the compiled result — **42 pages**, A4, 580,540 bytes, SHA-256 `7fd0896a2e715afd050f1fb1c84f00423d6b3bf64a51f93a007b4bbd37626ae3`. |

The manuscript contains **0 figures**, **6 tables**, **13 numbered equations**,
**13 worked examples**, and **83 theorem-like environments**.

### `compile/` — 10 files

`build_modern.sh` (four-pass driver), `bootstrap_texlive.sh` (assembles the TeX
Live 2024 tree), `texenv.sh`, `mktexlsr.py`, `map_ts1_lm.py`,
`BUILD_CORRECTIONS.md`, `README.md`, `README_BUILD.md`, and the legacy Phase 8A
`build.sh` / `fetch_texlive.sh`.

### `supplementary/` — 86 files (the program files and their outputs)

| group | files | what it is |
|---|---|---|
| `scripts/` | **22** | the Python programs — the computation behind the paper |
| `logs/` | **23** | the verbatim execution records the paper's numbers are read from |
| `generator_matrices/` | **29** | one generator matrix per certified code (28) plus `INDEX.json` |
| `parameter_tables/` | **8** | machine-readable CSV versions of the paper's tables |
| root | **4** | `README.md`, `ENVIRONMENT.md`, `CERTIFICATION_PROCEDURE.md`, `MANIFEST.sha256` |

**Start here:** `supplementary/README.md` (index and provenance), then
`supplementary/scripts/matrix_ring_lib.py` (the arithmetic library), then
`supplementary/CERTIFICATION_PROCEDURE.md` (what "certified" means).

### `documents/` — 13 files

Phase 21 policy and decision documents (Option C verification, the two proposed
data-availability statements, the 86-row private-access inventory, the
request-handling procedure, the draft editorial email, the staging note, the
final decision report), the Phase 22 compile report, and the Phase 19
submission documents (cover letter draft, submission checklist, highlights,
FFA guideline verification, formatting change record).

---

## Build the PDF

```bash
# 1. verify what you received
sha256sum -c SHA256_MANIFEST.txt

# 2. assemble TeX Live 2024 — skip if /home/user/texlive2024 already exists
sh compile/bootstrap_texlive.sh

# 3. four-pass build with genuine BibTeX
cd manuscript
TL=/home/user/texlive2024 SOURCE_DATE_EPOCH=1794268800 \
   sh ../compile/build_modern.sh "$(pwd)/build" main
```

Expected: 0 errors, 0 undefined citations, 0 undefined references, 0 missing
glyphs, 0 overfull boxes, 0 underfull boxes; **42 pages**; PDF SHA-256
`7fd0896a2e715afd050f1fb1c84f00423d6b3bf64a51f93a007b4bbd37626ae3`. The
`SOURCE_DATE_EPOCH` pin is what makes that hash reproducible — two independent
builds produced byte-identical output.

The bibliography is built by **genuine BibTeX 0.99d** with `plain.bst`
(13 entries, 78-line `.bbl`). No pybtex or other substitute is used.

---

## Run the programs

Pure **Python 3 standard library** — no numpy, sympy, Sage, GAP or Magma. Exact
arithmetic throughout; nothing is floating point. Recorded interpreter:
`Python 3.11.2`.

```bash
cd supplementary

# verify the package (85 hash lines, all OK)
sha256sum -c MANIFEST.sha256

# regenerate the generator matrices
cd scripts
python3 extract_certified_generators.py ../generator_matrices

# re-run the principal search (~9 minutes, ~370 MB RSS)
python3 phase7_extended_search.py > out.txt 2>&1
diff <(grep -v '\[[0-9]*s\]' out.txt) \
     <(grep -v '\[[0-9]*s\]' ../logs/phase7_extended_search_log.txt)
```

The `grep -v` strips elapsed-time annotations; the peak-memory line is the only
other expected difference. Dependency order is in `supplementary/README.md`
(`matrix_ring_lib.py` first).

The seed is fixed (`SEED = 20261210`) and every random choice comes from a
single `random.Random(SEED)` instance, so the search is deterministic.

### Third-party content

Exactly **one** file contains material not produced by this computation:
`supplementary/parameter_tables/comparison_grassl_q9.csv`, whose three rows
were read verbatim from codetables.de on **2026-11-04** and are cited in the
manuscript as reference [5]. Everything else is original work.

---

## Honest statement of scope

The manuscript does **not** claim record quantum parameters. It states plainly
that the stabilizer codes are *"at best equal to the best known distances"* and
that *"No record parameter is claimed."* The contribution is the algebraic
framework — Galois duality and hull theory over $M_2(A_t)$, the refutation of
principal-hull conjectures, the duality-preserving Gray map, and the quantum
constructions that follow — together with rigorously verified constructions.

Of the 28 certified codes, the ambient quantum cross-check is **exact for 11**
and gives a **proved lower bound for the remaining 17**. Two methods run per
code; **no code is certified by all three**, and the manuscript says so.
