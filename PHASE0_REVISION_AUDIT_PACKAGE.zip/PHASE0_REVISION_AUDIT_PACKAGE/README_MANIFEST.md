# PHASE0_REVISION_AUDIT_PACKAGE — file manifest

Project: *Quantum Error-Correcting Codes from Galois Hulls of Cyclic Codes over*
*Noncommutative Matrix Rings*

| | |
|---|---|
| Built | 2026-11-04 07:45:29 |
| Branch | `arena/59de606f-matrix-ring` |
| Git commit at build time | `f9c40bc` ("Phase 0 revision") |
| Files | 30 |
| Uncompressed size | 1,147,733 bytes |

**Verification:** `sha256` (first 16 hex digits) and byte size of every file, so the
auditor can confirm nothing was altered while packaging. Every file is a byte-exact
copy of the version in the repository at commit `f9c40bc`.

## Contents by requested item

| # | Requested item | Folder |
|---|----------------|--------|
| 1 | Complete Phase 0 original report | `01_Phase0_original_report/` |
| 2 | Revised Phase 0 report | `02_Phase0_revised_report/` |
| 3 | Complete pairing proofs | `03_Pairing_proofs/` |
| 4 | Nontrivial Galois experiments | `04_Galois_experiments/` (report + scripts + logs) |
| 5 | Alahmadi theorem reconciliation | `05_Alahmadi_reconciliation/` (report + script + log) |
| 6 | Updated theorem register | `06_Theorem_register/` (updated **and** original retained) |
| 7 | All computation scripts and execution logs | `07_Computation/` |
| 8 | Annotated bibliography and references | `08_Literature/` |
| 9 | Literature comparison matrix | `08_Literature/comparison_matrix.md` |
| 10 | Phase 0 final recommendation | `09_Final_recommendation/` |
| 11 | ChatGPT audit request | `10_Audit_request/` (revision + original) |
| (+) | Blueprint, repo README, decision log, changelog | `11_Supporting/` |

## Reading order for the auditor

1. `11_Supporting/Research_Blueprint.pdf` (controlling document)
2. `02_Phase0_revised_report/PHASE0_REVISION_REPORT.md` (master report, Tasks 1-3)
3. `09_Final_recommendation/UPDATED_PHASE0_FINAL_RECOMMENDATION.md` (GO/MODIFY/STOP)
4. `03_Pairing_proofs/PAIRING_COMPLETE_PROOFS.md` (Task 2 — the proofs)
5. `04_Galois_experiments/NONTRIVIAL_GALOIS_EXPERIMENTS.md` (Task 1)
6. `05_Alahmadi_reconciliation/ALAHMADI_THEOREM_RECONCILIATION.md` (Task 3)
7. `06_Theorem_register/UPDATED_THEOREM_REGISTER.md` (what is claimed, how strongly)
8. `07_Computation/UPDATED_COMPUTATION_SCRIPTS_AND_LOGS.md` (reproducibility)
9. `10_Audit_request/Phase0_revision_audit_request.md` (the prompt to paste into ChatGPT)

## Reproducing the computation (Python 3.11.2, standard library only)

```bash
cd 04_Galois_experiments   && python3 -u galois_duality_experiments.py full
cd 04_Galois_experiments   && python3 -u galois_t2_check.py
cd 05_Alahmadi_reconciliation && python3 -u alahmadi_reconciliation.py
cd 07_Computation          && python3 -u phase0_feasibility.py
```

(`matrix_ring_lib.py` must sit in the same directory as each script — copy it alongside.)

## Full file list (sha256 prefix · bytes · path)

```
5b10a6a405e8ab91      29,009  01_Phase0_original_report/Phase_0_Report.md
3de4000ed6a3449f      10,111  02_Phase0_revised_report/PHASE0_REVISION_REPORT.md
c276819999f103c7      27,554  03_Pairing_proofs/PAIRING_COMPLETE_PROOFS.md
8b980811878d6ca7      13,236  04_Galois_experiments/NONTRIVIAL_GALOIS_EXPERIMENTS.md
90d9fb715e2bb2a1      30,293  04_Galois_experiments/galois_duality_experiments.py
9ce5e1d8114e5409      14,752  04_Galois_experiments/galois_experiments_log.txt
552d1eda5bac2637      10,590  04_Galois_experiments/galois_t2_check.py
ca2982be10c3e009       1,571  04_Galois_experiments/galois_t2_log.txt
ee668cfcc212b71b      11,775  05_Alahmadi_reconciliation/ALAHMADI_THEOREM_RECONCILIATION.md
a69f22058619da4d      35,819  05_Alahmadi_reconciliation/alahmadi_reconciliation.py
941171e9eb6b0b96      27,409  05_Alahmadi_reconciliation/alahmadi_reconciliation_log.txt
c1d1fd501e6faa24      11,974  06_Theorem_register/UPDATED_THEOREM_REGISTER.md
6f749455b69a9d9c       6,662  06_Theorem_register/theorem_register_ORIGINAL.md
19491d874607b699       4,649  07_Computation/04_COMPUTATION_README.md
f74e801a0fb2b189       8,089  07_Computation/UPDATED_COMPUTATION_SCRIPTS_AND_LOGS.md
534389fc512890a6      23,797  07_Computation/matrix_ring_lib.py
7344628f27224595      25,093  07_Computation/phase0_feasibility.py
4d85c51a6a23e94b      25,932  07_Computation/phase0_results.txt
5779ff917734b8d3      26,007  07_Computation/phase0_stdout.txt
b1ea98897892ed08      18,841  08_Literature/annotated_bibliography.md
4bc3de5f74ccc76b       5,698  08_Literature/comparison_matrix.md
ff470260ebfbe178      13,626  08_Literature/references.bib
2911cdb4f21d4b80      11,276  09_Final_recommendation/UPDATED_PHASE0_FINAL_RECOMMENDATION.md
fcfca7a3edb3c7b5       5,277  10_Audit_request/Phase0_audit_request_ORIGINAL.md
731a984538e49180       7,332  10_Audit_request/Phase0_revision_audit_request.md
bce042b48deaeb97       6,641  11_Supporting/CHANGELOG.md
ed0002595951184c       7,178  11_Supporting/PROJECT_DECISION_LOG.md
6bb5320dfb5ad403       3,086  11_Supporting/REPO_ROOT_README.md
fc82e3de0011234c     697,329  11_Supporting/Research_Blueprint.pdf
75533487ccb7b099      27,127  11_Supporting/Research_Blueprint_extracted_text.txt
```

## Provenance / non-alteration statement

* No mathematical result was changed while packaging; the ZIP contains byte-exact
  copies of the repository files at commit `f9c40bc`.
* Nothing was deleted. Where a document has been superseded, **both** versions are
  included: `theorem_register_ORIGINAL.md` and `Phase0_audit_request_ORIGINAL.md`.
* No Phase 1-8 material is included: `05_MANUSCRIPT/` is still empty and no later-phase
  theorem has been proved.

