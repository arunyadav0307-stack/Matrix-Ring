# FINAL_FFA_MANUSCRIPT_COMPLETE_PACKAGE

LaTeX source, compiled PDF, build scripts and build logs of the manuscript

> **Quantum Error-Correcting Codes from Galois Hulls of Cyclic Codes over
> Noncommutative Matrix Rings**
> Arun Kumar Yadav

prepared for *Finite Fields and Their Applications* (Elsevier), "FFA".

The paper constructs q-ary quantum codes (stabilizer, CSS and
entanglement-assisted) from the Galois hulls of cyclic codes over the
noncommutative matrix ring M_2(F_q[u]/<u^t>) and certifies 28 codes by
exhaustive computation. No record parameters are claimed.

Everything needed to rebuild `main.pdf` is in this folder. The only outside
requirement is a LaTeX installation.

---

## 1. Status: please read first

This package holds the **latest manuscript text of the project** (Phase 23,
directory `PAPER/FFA_FINAL_SUBMISSION_V2/`), **compiled exactly as it stands**.
No wording, mathematics or result was changed to make the package.

The manuscript is **not yet in submission form**. These items are visible in
`main.pdf` and are the author's to settle:

| where in `main.pdf` | what is still open |
|---|---|
| p. 38, *Declaration of generative AI and AI-assisted technologies* | Placeholder only. It says that AI assistance was used extensively and that a declaration is required. The declaration itself has not been inserted (decision 1); two candidate wordings are drafted in `PHASE23_GENERATIVE_AI_DECLARATION.md`. |
| p. 37, *Acknowledgements* and *Author contributions (CRediT)* | Bracketed placeholders ("Researcher confirmation required"). |
| pp. 37-38, *Data availability* | Marked "PROPOSED - FFA POLICY CONFIRMATION PENDING". |
| p. 37, *Declaration of competing interests* and *Funding* | The statements are in place; each is followed by an internal "Status: CONFIRMED ..." note that points to a project file. |
| p. 34, section 9 | The statement that no entanglement-assisted code table exists was recorded as incorrect in the project's Phase 23 review (decision 11). A replacement sentence is drafted in `PHASE23_THIRD_PARTY_DATA_REVIEW.md`, section E5, and has not been applied. The same statement is repeated on pp. 6, 35, 36 and 37 (sections 1, 9 and 10); those four sentences have no drafted replacement. |

The full list of sixteen pending author decisions is in
`PHASE23_FFA_FINALIZATION/PHASE23_RESEARCHER_DECISION_SHEET.md` in the
repository. According to the project record, nothing has been submitted to the
journal.

---

## 2. Manuscript details

| | |
|---|---|
| Title | Quantum Error-Correcting Codes from Galois Hulls of Cyclic Codes over Noncommutative Matrix Rings |
| Author | Arun Kumar Yadav (single author as listed in the manuscript; corresponding author) |
| Affiliation | School of Basic and Applied Sciences, K.R. Mangalam University, Sohna Road, Gurugram, Haryana, 122103, India |
| E-mail | arunyadav0307@gmail.com |
| Target journal | Finite Fields and Their Applications (Elsevier) |
| Keywords | cyclic codes over rings; matrix rings; Galois duality; Galois hulls; Gray map; quantum stabilizer codes; entanglement-assisted quantum codes |
| MSC 2020 | 94B05, 94B15, 94B60, 16S50, 11T71 |
| Length | 42 pages, A4; 10 sections and 2 appendices; 6 numbered tables; no figures; 13 references |
| LaTeX | class `article` (11pt, a4paper); bibliography style `plain`; engine pdfLaTeX |
| Research data | <https://github.com/arunyadav0307-stack/Matrix-Ring/tree/3752a6c0e921ab21a6f78877f154e7e959f4c418/research-data> (the link printed in the manuscript) |
| Source of this package | repository `arunyadav0307-stack/Matrix-Ring`, commit `9043c1d476ffa3bc2c715eabcd1c44c9fa54d01f`, directory `PAPER/FFA_FINAL_SUBMISSION_V2/` |

---

## 3. Contents (29 files)

| file | description |
|---|---|
| `main.tex` | Main LaTeX file: preamble, title, abstract and declarations. It inputs the twelve files in `sections/`. |
| `sections/01_introduction.tex` to `sections/10_conclusion.tex` | The ten numbered sections (10 files). |
| `sections/appendix_tables.tex`, `sections/appendix_reproducibility.tex` | Appendices A and B. |
| `references.bib` | BibTeX database: 13 entries, all of them cited. |
| `main.bbl` | The bibliography that BibTeX generated from `references.bib`. |
| `plain.bst` | The standard BibTeX `plain` style (version 0.99b, unmodified) that `\bibliographystyle{plain}` calls for. Included for completeness; standard TeX distributions ship the same file. |
| `main.pdf` | The compiled manuscript: 42 pages, 580,019 bytes. |
| `compile_manuscript.sh` | The four-pass build for a computer that has LaTeX installed (route A below). |
| `compile/bootstrap_texlive.sh` | Project script: installs a TeX Live 2024 toolchain on a Linux machine that has no TeX (route B). |
| `compile/build_modern.sh` | Project script: the four-pass build with that toolchain (route B). This script produced `main.pdf`. |
| `compile/mktexlsr.py`, `compile/map_ts1_lm.py`, `compile/texmf-local/tex/latex/ts1-cmr-lm-subst/ts1cmr.fd` | Support files of the two project scripts: the file-name database writer, and the substitution of Latin Modern for the TS1 text-symbol font (used for the list bullet). Not needed for route A. |
| `logs/main.log` | pdfTeX log of the final pass of the build that produced `main.pdf`. |
| `logs/main.blg` | BibTeX log of the same build. |
| `logs/build_transcript.txt` | Console transcript of that build: the four passes and the summary. |
| `logs/toolchain_bootstrap_transcript.txt` | Console transcript of the toolchain installation. |
| `FILE_MANIFEST.txt` | SHA-256 of each of the other 28 files, in `sha256sum` format. |
| `README.md` | This file. |

Not included, and why:

- **Figures and images:** the manuscript has none.
- **LaTeX packages:** `geometry`, `inputenc`, `amsmath`, `amssymb`, `amsthm`,
  `array`, `booktabs`, `longtable`, `enumitem`, `xcolor`, `url` and `hyperref`
  are part of every standard LaTeX distribution.
- **Supplementary PDF files:** the project has none. The research data are
  online at the address in section 2.
- **Auxiliary files** (`.aux`, `.out`, `.toc`): LaTeX recreates them.

Comments in `main.tex` and in the scripts name other project files (for example
`compile/BUILD_CORRECTIONS.md`). Those are internal records kept in the
repository; the build does not need them.

---

## 4. How to compile

### Route A: a computer with LaTeX installed (TeX Live, MacTeX, MiKTeX)

Open a terminal in this folder and run the four standard commands:

```
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

This rebuilds `main.pdf` and `main.bbl` in place. On Linux or macOS you can
instead run

```
sh compile_manuscript.sh
```

which performs the same four passes in a new sub-folder `rebuild/` and leaves
the shipped files untouched. The result is `rebuild/main.pdf`.

### Route B: a Linux machine without LaTeX (the project's own toolchain)

```
sh compile/bootstrap_texlive.sh     # once, under a minute; installs into /home/user/texlive2024
sh compile/build_modern.sh          # result: build_modern/main.pdf
```

To install somewhere else, put `TL=/your/path` in front of both commands.
Requirements: x86-64 Linux; `gcc`, `make`, `python3`, `curl`, `git`, `tar`; the
GitHub command-line tool `gh`, signed in; network access to github.com,
api.github.com, files.pythonhosted.org and registry.npmjs.org.

### Expected result

42 pages; 0 errors; 0 undefined citations; 0 undefined references; 0 overfull
or underfull boxes.

With the route B toolchain and `SOURCE_DATE_EPOCH=1794268800` (both scripts
set it by default) the build reproduces `main.pdf` byte for byte:

```
SHA-256  d125cc096f0c7344f5435193bb410813c3bcc1175cb828b5c9980b00446b5ee1
```

Without that variable only the `/CreationDate`, `/ModDate` and `/ID` entries of
the PDF differ. Another LaTeX distribution or version uses other package and
font versions, so its PDF will not be byte-identical; the content should be the
same 42 pages. Only the toolchain described in section 5 was tested.

---

## 5. The build shipped in this package

| | |
|---|---|
| Date | 2026-11-10, 16:05 UTC |
| Command | `TL=/home/user/texlive2024 SOURCE_DATE_EPOCH=1794268800 sh compile/build_modern.sh "$(pwd)/build" main`, the command recorded in the project's Phase 23 build report |
| Sequence | pdflatex → bibtex → pdflatex → pdflatex |
| Engine | pdfTeX 3.141592653-2.6-1.40.26 (TeX Live 2024); LaTeX2e 2023-11-01, patch level 1 |
| BibTeX | BibTeX 0.99d, style file `plain.bst` |
| Errors and warnings | 0 errors; 0 warnings; 0 undefined citations; 0 undefined references; 0 overfull or underfull boxes; 0 missing characters |
| Output | `main.pdf`: 42 pages, A4, 580,019 bytes, 29 fonts, all embedded |
| Citations | 13 keys cited; 13 entries in `references.bib`; 13 items in `main.bbl` |
| Cross-references | 116 labels; 264 reference commands; none unresolved |
| Tables and figures | Tables 1 to 4, A.1 and A.2 on pages 18, 32, 33, 35, 39 and 40; no figures |
| SHA-256 of `main.pdf` | `d125cc096f0c7344f5435193bb410813c3bcc1175cb828b5c9980b00446b5ee1`, equal to the value in the project's Phase 23 build report |

The toolchain is a TeX Live 2024 tree that `compile/bootstrap_texlive.sh`
assembles, because the build machine had no TeX and could not reach CTAN. It
consists of the TinyTeX distribution of TeX Live 2024 (texmf tree and pdfTeX
binary), a few standard files (`amsfonts`, `amsthm`, `plain.bst`) from a
TeX Live 2015 bundle, `booktabs.sty`, and BibTeX 0.99d and kpathsea compiled
from the TeX Live source tree. The TinyTeX download, the TeX Live 2015
bundle and `booktabs.sty` are checked against recorded SHA-256 values. It is
not a full `install-tl` installation.

---

## 6. Checking the files

```
sha256sum -c FILE_MANIFEST.txt            # Linux
shasum -a 256 -c FILE_MANIFEST.txt        # macOS
Get-FileHash main.pdf -Algorithm SHA256   # Windows PowerShell, one file at a time
```

Every line should end in `OK`. If you rebuild in place (route A, four
commands), `main.pdf` will afterwards differ from the manifest, as explained
in section 4.

---

## 7. Provenance

Assembled on 2026-11-10 from commit `9043c1d476ffa3bc2c715eabcd1c44c9fa54d01f`
of <https://github.com/arunyadav0307-stack/Matrix-Ring> (branch
`arena/582e83ad-matrix-ring`).

- `main.tex`, `references.bib`, `sections/` and the files under `compile/` are
  byte-identical to `PAPER/FFA_FINAL_SUBMISSION_V2/` at that commit.
- `main.pdf`, `main.bbl` and the files under `logs/` come from the build
  described in section 5.
- `plain.bst` is the copy that BibTeX used in that build.
- `compile_manuscript.sh`, `README.md` and `FILE_MANIFEST.txt` were written
  for this package.

The package was compiled and assembled by an AI coding agent (Arena.ai Agent
Mode) at the author's request.
