#!/bin/sh
# ---------------------------------------------------------------------
#  compile_manuscript.sh -- the standard four-pass LaTeX build
#
#      pdflatex -> bibtex -> pdflatex -> pdflatex
#
#  For a computer that already has a LaTeX distribution (TeX Live,
#  MacTeX, MiKTeX) with pdflatex and bibtex on the PATH.
#
#  The build runs in a fresh sub-directory, ./rebuild, so the shipped
#  main.pdf and main.bbl are not overwritten and FILE_MANIFEST.txt keeps
#  verifying.  Result: ./rebuild/main.pdf
#
#  Usage:  sh compile_manuscript.sh
# ---------------------------------------------------------------------
set -e

HERE=$(cd "$(dirname "$0")" && pwd)
OUT=$HERE/rebuild

for tool in pdflatex bibtex; do
    command -v "$tool" >/dev/null 2>&1 || {
        echo "compile_manuscript.sh: '$tool' was not found on the PATH." >&2
        echo "  Install a LaTeX distribution, or use route B in README.md." >&2
        exit 1
    }
done

rm -rf "$OUT"
mkdir -p "$OUT"
cp "$HERE/main.tex" "$HERE/references.bib" "$HERE/plain.bst" "$OUT/"
cp -r "$HERE/sections" "$OUT/"

# Fixed timestamp for the PDF /CreationDate and /ModDate fields
# (2026-11-10T00:00:00Z, the value used for the shipped main.pdf).
# Export SOURCE_DATE_EPOCH beforehand to override it.
SOURCE_DATE_EPOCH=${SOURCE_DATE_EPOCH:-1794268800}
export SOURCE_DATE_EPOCH

cd "$OUT"

run_pdflatex() {
    echo "== pass $1: pdflatex =="
    if ! pdflatex -interaction=nonstopmode -halt-on-error main.tex \
            > "pass$1_pdflatex_console.txt" 2>&1; then
        echo "   pdflatex FAILED; end of rebuild/pass$1_pdflatex_console.txt:" >&2
        tail -n 25 "pass$1_pdflatex_console.txt" >&2
        exit 1
    fi
}

run_pdflatex 1

echo "== pass 2: bibtex =="
set +e
bibtex main
status=$?
set -e
# BibTeX exits with 1 for warnings and with 2 or more for errors.
if [ "$status" -ge 2 ]; then
    echo "   bibtex FAILED (exit status $status); see rebuild/main.blg" >&2
    exit 1
fi
if [ "$status" -eq 1 ]; then
    echo "   bibtex reported warnings; see rebuild/main.blg"
fi

run_pdflatex 3
run_pdflatex 4

[ -f main.pdf ] || { echo "FATAL: no PDF was produced" >&2; exit 1; }

count() { grep -cE "$1" main.log || true; }

echo
echo "== summary (rebuild/main.log) =="
printf '   %-24s %s\n' "LaTeX errors"         "$(count '^! ')"
printf '   %-24s %s\n' "undefined citations"  "$(count 'Citation .* undefined')"
printf '   %-24s %s\n' "undefined references" "$(count 'Reference .* undefined')"
printf '   %-24s %s\n' "overfull boxes"       "$(count 'Overfull .hbox')"
printf '   %-24s %s\n' "missing characters"   "$(count 'Missing character')"
grep -E '^Output written' main.log | sed 's/^/   /'
echo "   result: $OUT/main.pdf"
